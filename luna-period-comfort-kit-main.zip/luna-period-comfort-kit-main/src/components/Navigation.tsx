
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Calendar, Package, Heart } from "lucide-react";

const Navigation = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-luna-purple flex items-center justify-center mr-2">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-luna-purple">Luna Kit</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <NavLink to="/tracker" active={location.pathname === "/tracker"}>
              <Calendar className="mr-2 h-4 w-4" />
              Period Tracker
            </NavLink>
            <NavLink to="/shop" active={location.pathname === "/shop"}>
              <Package className="mr-2 h-4 w-4" />
              Shop
            </NavLink>
            <NavLink to="/about" active={location.pathname === "/about"}>
              <Heart className="mr-2 h-4 w-4" />
              About Us
            </NavLink>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="outline"
              className="text-luna-purple"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <span className="sr-only">Open menu</span>
              {isMobileMenuOpen ? (
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16m-7 6h7"
                  />
                </svg>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white shadow-lg">
            <MobileNavLink 
              to="/tracker" 
              active={location.pathname === "/tracker"}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Period Tracker
            </MobileNavLink>
            <MobileNavLink 
              to="/shop" 
              active={location.pathname === "/shop"}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Package className="mr-2 h-4 w-4" />
              Shop
            </MobileNavLink>
            <MobileNavLink 
              to="/about" 
              active={location.pathname === "/about"}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Heart className="mr-2 h-4 w-4" />
              About Us
            </MobileNavLink>
          </div>
        </div>
      )}
    </nav>
  );
};

const NavLink = ({ 
  to, 
  children, 
  active = false 
}: { 
  to: string; 
  children: React.ReactNode; 
  active?: boolean;
}) => (
  <Link
    to={to}
    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      active
        ? "bg-luna-light-purple text-luna-purple"
        : "text-gray-600 hover:bg-luna-light-purple hover:text-luna-purple"
    }`}
  >
    {children}
  </Link>
);

const MobileNavLink = ({ 
  to, 
  children, 
  active = false,
  onClick
}: { 
  to: string; 
  children: React.ReactNode; 
  active?: boolean;
  onClick?: () => void;
}) => (
  <Link
    to={to}
    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium block ${
      active
        ? "bg-luna-light-purple text-luna-purple"
        : "text-gray-600 hover:bg-luna-light-purple hover:text-luna-purple"
    }`}
    onClick={onClick}
  >
    {children}
  </Link>
);

export default Navigation;
