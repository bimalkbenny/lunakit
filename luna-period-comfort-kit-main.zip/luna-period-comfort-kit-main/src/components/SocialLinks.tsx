
import { ExternalLink } from "lucide-react";

interface SocialLinksProps {
  className?: string;
}

const SocialLinks = ({ className = "" }: SocialLinksProps) => {
  return (
    <div className={`flex items-center space-x-4 ${className}`}>
      {/* WhatsApp Link */}
      <a 
        href="https://wa.me/1234567890" 
        target="_blank" 
        rel="noopener noreferrer"
        className="transition-transform hover:scale-110"
        aria-label="WhatsApp"
      >
        <div className="h-10 w-10 rounded-full bg-[#25D366] flex items-center justify-center transition-transform hover:scale-110">
          <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.371-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345z"></path>
            <path d="M20.52 3.449C12.831-3.984.106 1.407.101 12.268c0 2.031.525 4.127 1.44 5.926l-1.488 5.45 5.561-1.432c1.742.939 3.709 1.44 5.745 1.44h.006c9.845-.001 15.272-11.265 8.155-18.811L20.52 3.45zm-8.248 18.316h-.005c-1.745 0-3.42-.466-4.892-1.363l-.35-.21-3.625.953.968-3.534-.231-.371c-.986-1.578-1.492-3.391-1.492-5.261.001-5.445 4.457-9.885 9.944-9.885 2.655 0 5.163 1.035 7.07 2.924 1.909 1.894 2.955 4.398 2.954 7.061-.001 5.446-4.456 9.887-9.946 9.887"></path>
          </svg>
        </div>
      </a>

      {/* Instagram Link */}
      <a 
        href="https://www.instagram.com/lunakit" 
        target="_blank" 
        rel="noopener noreferrer"
        className="transition-transform hover:scale-110"
        aria-label="Instagram"
      >
        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 flex items-center justify-center">
          <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
          </svg>
        </div>
      </a>

      {/* Facebook Link */}
      <a 
        href="https://www.facebook.com/lunakit" 
        target="_blank" 
        rel="noopener noreferrer"
        className="transition-transform hover:scale-110"
        aria-label="Facebook"
      >
        <div className="h-10 w-10 rounded-full bg-[#1877F2] flex items-center justify-center">
          <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
          </svg>
        </div>
      </a>

      <div className="flex items-center text-xs text-gray-500">
        <ExternalLink className="h-3 w-3 mr-1" />
        <span>Connect with us</span>
      </div>
    </div>
  );
};

export default SocialLinks;
