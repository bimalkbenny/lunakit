
import { useState } from "react";
import { Plus, Minus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";

interface KitItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CustomKitBuilderProps {
  onAddToCart: (items: KitItem[], totalPrice: number) => void;
}

const CustomKitBuilder = ({ onAddToCart }: CustomKitBuilderProps) => {
  const [kitName, setKitName] = useState("My Custom Kit");
  
  const [items, setItems] = useState<KitItem[]>([
    { id: "pads", name: "Sanitary Pads", price: 0.80, quantity: 5 },
    { id: "intimate_wash", name: "Intimate Wash (100ml)", price: 4.99, quantity: 1 },
    { id: "chocolates", name: "Chocolates", price: 0.50, quantity: 2 },
    { id: "tissues", name: "Tissues (Pack)", price: 1.50, quantity: 1 },
    { id: "toilet_covers", name: "Toilet Seat Covers", price: 0.30, quantity: 3 },
    { id: "pain_patches", name: "Pain Relief Patches", price: 1.99, quantity: 0 },
    { id: "tampons", name: "Tampons", price: 0.90, quantity: 0 },
    { id: "panty_liners", name: "Panty Liners", price: 0.60, quantity: 0 },
    { id: "wet_wipes", name: "Wet Wipes", price: 1.99, quantity: 0 },
  ]);
  
  const updateItemQuantity = (id: string, change: number) => {
    setItems(
      items.map(item => 
        item.id === id 
          ? { ...item, quantity: Math.max(0, item.quantity + change) } 
          : item
      )
    );
  };
  
  const calculateTotal = () => {
    return items.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  const handleAddToCart = () => {
    const selectedItems = items.filter(item => item.quantity > 0);
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please add at least one item to your kit",
        variant: "destructive"
      });
      return;
    }
    
    onAddToCart(selectedItems, calculateTotal());
    
    toast({
      title: "Custom kit added to cart",
      description: `${kitName} has been added to your cart`
    });
  };
  
  return (
    <Card className="p-6 bg-white shadow-md border border-luna-light-purple">
      <h3 className="text-xl font-bold text-luna-purple mb-4">Build Your Custom Period Kit</h3>
      
      <div className="mb-4">
        <Label htmlFor="kitName" className="text-gray-700">Kit Name</Label>
        <Input 
          id="kitName" 
          value={kitName} 
          onChange={(e) => setKitName(e.target.value)} 
          className="mt-1"
        />
      </div>
      
      <div className="space-y-4 my-6">
        {items.map(item => (
          <div key={item.id} className="flex items-center justify-between p-2 rounded-lg bg-purple-50">
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-sm text-gray-600">${item.price.toFixed(2)} each</p>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8" 
                onClick={() => updateItemQuantity(item.id, -1)}
                disabled={item.quantity === 0}
              >
                <Minus className="h-4 w-4" />
              </Button>
              
              <span className="w-6 text-center">{item.quantity}</span>
              
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8" 
                onClick={() => updateItemQuantity(item.id, 1)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
      
      <div className="flex items-center justify-between mt-6 py-3 border-t border-gray-200">
        <div>
          <p className="text-sm text-gray-600">Items: {items.reduce((sum, item) => sum + item.quantity, 0)}</p>
          <p className="text-lg font-bold text-luna-purple">Total: ${calculateTotal().toFixed(2)}</p>
        </div>
        
        <Button onClick={handleAddToCart} className="bg-luna-purple hover:bg-purple-600">
          <Check className="mr-2 h-4 w-4" /> Add to Cart
        </Button>
      </div>
    </Card>
  );
};

export default CustomKitBuilder;
