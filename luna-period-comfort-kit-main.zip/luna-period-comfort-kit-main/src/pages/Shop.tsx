
import { useState } from "react";
import { Link } from "react-router-dom";
import { Package, Heart, ShoppingCart, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/Navigation";
import CustomKitBuilder from "@/components/CustomKitBuilder";
import { toast } from "@/hooks/use-toast";

// Mock product data
const products = [
  {
    id: 1,
    name: "Basic Comfort Kit",
    description: "Essential period care with pads, tissues, and chocolates.",
    price: 12.99,
    image: "/placeholder.svg",
    category: "kits",
    bestSeller: true,
    items: ["10 Sanitary Pads", "Intimate Wash (50ml)", "2 Chocolates", "5 Tissues", "2 Toilet Seat Covers"]
  },
  {
    id: 2,
    name: "Premium Comfort Kit",
    description: "Complete period care with all essentials plus pain relief.",
    price: 18.99,
    image: "/placeholder.svg",
    category: "kits",
    bestSeller: false,
    items: ["15 Sanitary Pads", "Intimate Wash (100ml)", "5 Chocolates", "10 Tissues", "5 Toilet Seat Covers", "3 Pain Relief Patches"]
  },
  {
    id: 3,
    name: "Monthly Subscription Box",
    description: "Get a fresh comfort kit delivered every month.",
    price: 15.99,
    image: "/placeholder.svg",
    category: "subscription",
    bestSeller: true,
    items: ["15 Sanitary Pads", "Intimate Wash (100ml)", "5 Chocolates", "10 Tissues", "5 Toilet Seat Covers", "3 Pain Relief Patches"]
  },
  {
    id: 4,
    name: "Organic Sanitary Pads",
    description: "Pack of 10 organic cotton sanitary pads.",
    price: 6.99,
    image: "/placeholder.svg",
    category: "pads",
    bestSeller: false,
    items: []
  },
  {
    id: 5,
    name: "Intimate Wash",
    description: "Gentle pH-balanced intimate wash for period hygiene.",
    price: 8.99,
    image: "/placeholder.svg",
    category: "hygiene",
    bestSeller: false,
    items: []
  },
  {
    id: 6,
    name: "Heat Therapy Patches",
    description: "Self-heating patches for period cramp relief.",
    price: 9.99,
    image: "/placeholder.svg",
    category: "pain_relief",
    bestSeller: true,
    items: []
  },
];

interface CartItem {
  id: number | string;
  name: string;
  price: number;
  quantity: number;
}

const Shop = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  const addToCart = (productId: number) => {
    const existingItem = cart.find(item => item.id === productId);
    const product = products.find(p => p.id === productId);
    
    if (!product) return;
    
    if (existingItem) {
      setCart(
        cart.map(item => 
          item.id === productId 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        )
      );
    } else {
      setCart([...cart, { 
        id: productId, 
        name: product.name,
        price: product.price,
        quantity: 1 
      }]);
    }
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`
    });
    
    setTimeout(() => setIsCartOpen(true), 500);
  };
  
  const handleAddCustomKit = (items: any[], totalPrice: number) => {
    const kitId = `custom-${Date.now()}`;
    const customKit = {
      id: kitId,
      name: "Custom Kit",
      price: totalPrice,
      quantity: 1
    };
    
    setCart([...cart, customKit]);
    setIsCartOpen(true);
  };
  
  const updateQuantity = (itemId: number | string, newQuantity: number) => {
    if (newQuantity <= 0) {
      setCart(cart.filter(item => item.id !== itemId));
    } else {
      setCart(
        cart.map(item => 
          item.id === itemId 
            ? { ...item, quantity: newQuantity } 
            : item
        )
      );
    }
  };
  
  const removeFromCart = (itemId: number | string) => {
    setCart(cart.filter(item => item.id !== itemId));
    
    toast({
      title: "Item removed",
      description: "Item has been removed from your cart"
    });
  };
  
  const filteredProducts = activeCategory === "all" 
    ? products 
    : products.filter(product => product.category === activeCategory);
    
  const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
  const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-luna-blue/20">
      <Navigation />
      
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <h1 className="text-3xl font-bold text-luna-purple mb-4 md:mb-0 animate-fade-in">Shop Period Products</h1>
          
          <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="flex items-center hover-scale animate-fade-in">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Cart ({totalItems})
              </Button>
            </SheetTrigger>
            <SheetContent className="w-full sm:max-w-md">
              <SheetHeader>
                <SheetTitle>Shopping Cart</SheetTitle>
              </SheetHeader>
              
              {cart.length > 0 ? (
                <div className="flex flex-col h-full">
                  <div className="flex-grow space-y-4 overflow-y-auto py-4">
                    {cart.map((item) => (
                      <div key={item.id} className="flex justify-between items-center p-4 border-b group hover:bg-gray-50 rounded-lg">
                        <div className="flex-grow">
                          <h4 className="font-medium">{item.name}</h4>
                          <div className="text-sm text-gray-500">${item.price.toFixed(2)} each</div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <button 
                            className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-100"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            -
                          </button>
                          <span className="w-6 text-center">{item.quantity}</span>
                          <button 
                            className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-100"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            +
                          </button>
                          <button 
                            className="ml-2 text-gray-400 hover:text-red-500"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M3 6h18"></path>
                              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-auto border-t pt-4">
                    <div className="flex justify-between font-medium text-lg mb-4">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="space-y-2">
                      <SheetClose asChild>
                        <Button className="w-full bg-luna-purple hover:bg-purple-600" asChild>
                          <Link to="/checkout">Checkout</Link>
                        </Button>
                      </SheetClose>
                      <SheetClose asChild>
                        <Button variant="outline" className="w-full">
                          Continue Shopping
                        </Button>
                      </SheetClose>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-[60vh]">
                  <ShoppingCart className="w-16 h-16 text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium text-gray-700 mb-2">Your cart is empty</h3>
                  <p className="text-gray-500 mb-6 text-center">Looks like you haven't added any products yet.</p>
                  <SheetClose asChild>
                    <Button>Continue Shopping</Button>
                  </SheetClose>
                </div>
              )}
            </SheetContent>
          </Sheet>
        </div>
        
        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory}>
          <TabsList className="mb-8 bg-white p-1 border border-gray-200 rounded-lg animate-fade-in">
            <TabsTrigger value="all">All Products</TabsTrigger>
            <TabsTrigger value="kits">Comfort Kits</TabsTrigger>
            <TabsTrigger value="subscription">Subscriptions</TabsTrigger>
            <TabsTrigger value="pads">Pads</TabsTrigger>
            <TabsTrigger value="hygiene">Hygiene</TabsTrigger>
            <TabsTrigger value="pain_relief">Pain Relief</TabsTrigger>
            <TabsTrigger value="custom">Custom Kit</TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeCategory !== "custom" ? activeCategory : ""}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product, index) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={() => addToCart(product.id)}
                  animationDelay={index * 100} 
                />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="custom">
            <div className="max-w-3xl mx-auto animate-fade-in">
              <CustomKitBuilder onAddToCart={handleAddCustomKit} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    description: string;
    price: number;
    image: string;
    category: string;
    bestSeller: boolean;
    items: string[];
  };
  onAddToCart: () => void;
  animationDelay: number;
}

const ProductCard = ({ product, onAddToCart, animationDelay }: ProductCardProps) => {
  const [showDetails, setShowDetails] = useState(false);
  
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 animate-scale-in" style={{ animationDelay: `${animationDelay}ms` }}>
      <div className="relative">
        <div className="h-48 bg-luna-light-purple flex items-center justify-center">
          {product.category === "kits" && (
            <Package className="h-20 w-20 text-luna-purple animate-pulse" />
          )}
          {product.category === "subscription" && (
            <div className="flex items-center">
              <Package className="h-16 w-16 text-luna-purple mr-2" />
              <Heart className="h-12 w-12 text-luna-pink" />
            </div>
          )}
          {product.category === "pads" && (
            <Package className="h-16 w-16 text-luna-purple" />
          )}
          {product.category === "hygiene" && (
            <Package className="h-16 w-16 text-luna-purple" />
          )}
          {product.category === "pain_relief" && (
            <Package className="h-16 w-16 text-luna-purple" />
          )}
        </div>
        
        {product.bestSeller && (
          <Badge className="absolute top-4 right-4 bg-luna-purple">
            Best Seller
          </Badge>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2 text-luna-purple">{product.name}</h3>
        <p className="text-gray-600 mb-4">{product.description}</p>
        
        {product.items.length > 0 && (
          <>
            <button 
              onClick={() => setShowDetails(!showDetails)}
              className="text-sm text-luna-purple hover:underline mb-4 flex items-center"
            >
              {showDetails ? "Hide details" : "Show kit contents"} 
              <span className="ml-1">{showDetails ? "▲" : "▼"}</span>
            </button>
            
            {showDetails && (
              <ul className="text-sm text-gray-600 mb-4 pl-5 list-disc">
                {product.items.map((item, index) => (
                  <li key={index} className="animate-slide-in" style={{ animationDelay: `${index * 50}ms` }}>{item}</li>
                ))}
              </ul>
            )}
          </>
        )}
        
        <div className="flex items-center justify-between mt-4">
          <span className="text-2xl font-bold text-luna-purple">${product.price.toFixed(2)}</span>
          <Button onClick={onAddToCart} className="bg-luna-purple hover:bg-purple-600 hover-scale">
            <Plus className="mr-2 h-4 w-4" /> Add to Cart
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Shop;
