
import { useState } from "react";
import { Calendar as CalendarIcon, Plus, Minus, ChevronRight, ChevronLeft } from "lucide-react";
import { format, addDays, subDays, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, getDay, differenceInDays } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";
import PeriodHistoryForm from "@/components/PeriodHistoryForm";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useIsMobile } from "@/hooks/use-mobile";

const symptoms = [
  { id: "cramps", name: "Cramps", color: "bg-red-500" },
  { id: "headache", name: "Headache", color: "bg-orange-500" },
  { id: "bloating", name: "Bloating", color: "bg-yellow-500" },
  { id: "fatigue", name: "Fatigue", color: "bg-green-500" },
  { id: "mood_swings", name: "Mood Swings", color: "bg-blue-500" },
  { id: "backache", name: "Backache", color: "bg-purple-500" },
  { id: "tender_breasts", name: "Tender Breasts", color: "bg-pink-500" },
  { id: "acne", name: "Acne", color: "bg-indigo-500" },
];

const moodOptions = [
  { id: "happy", name: "Happy", emoji: "😊" },
  { id: "calm", name: "Calm", emoji: "😌" },
  { id: "irritable", name: "Irritable", emoji: "😤" },
  { id: "anxious", name: "Anxious", emoji: "😰" },
  { id: "sad", name: "Sad", emoji: "😢" },
  { id: "tired", name: "Tired", emoji: "😴" },
];

const Tracker = () => {
  const isMobile = useIsMobile();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [calendarMonth, setCalendarMonth] = useState(new Date());
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [flowLevel, setFlowLevel] = useState(0);
  const [isFormOpen, setIsFormOpen] = useState(true);
  
  // Period data state
  const [periodStart, setPeriodStart] = useState<Date | null>(null);
  const [periodEnd, setPeriodEnd] = useState<Date | null>(null);
  const [cycleLength, setCycleLength] = useState(28);
  const [periodLength, setPeriodLength] = useState(5);
  
  const isPeriodDay = (date: Date) => {
    if (!periodStart || !periodEnd) return false;
    
    // Check if the date is within the actual tracked period
    if (date >= periodStart && date <= periodEnd) {
      return true;
    }
    
    // Predict next period based on cycle length
    if (periodStart && cycleLength) {
      const daysSinceStart = differenceInDays(date, periodStart);
      return daysSinceStart % cycleLength < periodLength;
    }
    
    return false;
  };

  const handlePrevMonth = () => {
    setCalendarMonth(subMonths(calendarMonth, 1));
  };

  const handleNextMonth = () => {
    setCalendarMonth(addMonths(calendarMonth, 1));
  };

  const handleSymptomToggle = (symptomId: string) => {
    if (selectedSymptoms.includes(symptomId)) {
      setSelectedSymptoms(selectedSymptoms.filter(id => id !== symptomId));
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptomId]);
    }
  };

  const handleMoodSelection = (moodId: string) => {
    setSelectedMood(selectedMood === moodId ? null : moodId);
  };
  
  const handleSavePeriodHistory = (start: Date, end: Date) => {
    setPeriodStart(start);
    setPeriodEnd(end);
    
    // Calculate period length based on the entered dates
    const newPeriodLength = differenceInDays(end, start) + 1;
    setPeriodLength(newPeriodLength);
    
    setIsFormOpen(false);
  };
  
  const calculateNextPeriod = () => {
    if (!periodStart || !cycleLength) return "Unknown";
    
    const nextPeriodStart = addDays(periodStart, cycleLength);
    const today = new Date();
    const daysUntil = differenceInDays(nextPeriodStart, today);
    
    if (daysUntil < 0) {
      // Period is overdue or we need to calculate the next one
      const cyclesPassed = Math.floor(Math.abs(daysUntil) / cycleLength) + 1;
      const actualNextStart = addDays(periodStart, cycleLength * cyclesPassed);
      const actualDaysUntil = differenceInDays(actualNextStart, today);
      return `In ${actualDaysUntil} days`;
    }
    
    return `In ${daysUntil} days`;
  };
  
  const calculateCurrentDay = () => {
    if (!periodStart || !cycleLength) return "Unknown";
    
    const today = new Date();
    const daysSinceStart = differenceInDays(today, periodStart);
    const currentCycleDay = (daysSinceStart % cycleLength) + 1;
    
    return `Day ${currentCycleDay} of ${cycleLength}`;
  };

  const renderCalendarDays = () => {
    const monthStart = startOfMonth(calendarMonth);
    const monthEnd = endOfMonth(calendarMonth);
    const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
    
    // Get the day of the week for the first day of the month (0 = Sunday, 1 = Monday, etc.)
    const startDay = getDay(monthStart);
    
    // Create placeholder elements for days before the first of the month
    const placeholders = Array.from({ length: startDay }, (_, i) => (
      <div key={`placeholder-${i}`} className="h-10"></div>
    ));

    return (
      <>
        {/* Day headers */}
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
          <div key={day} className="text-center text-xs font-medium text-gray-500 py-1">
            {day}
          </div>
        ))}

        {/* Empty placeholders */}
        {placeholders}

        {/* Calendar days */}
        {days.map(day => {
          const isPeriod = isPeriodDay(day);
          const isCurrentDay = isToday(day);
          const isSelected = isSameDay(day, selectedDate);
          
          return (
            <button
              key={day.toString()}
              onClick={() => setSelectedDate(day)}
              className={`h-10 w-10 mx-auto rounded-full flex items-center justify-center text-sm
                ${isSelected ? "bg-luna-purple text-white" : ""} 
                ${isCurrentDay && !isSelected ? "border-2 border-luna-purple" : ""}
                ${isPeriod && !isSelected ? "bg-luna-pink" : ""}`}
            >
              {format(day, "d")}
            </button>
          );
        })}
      </>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-luna-light-purple">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-luna-purple mb-8">Period Tracker</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar Section */}
          <Card className="p-6 col-span-1 lg:col-span-2 shadow-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold flex items-center text-gray-800">
                <CalendarIcon className="mr-2 h-5 w-5" />
                {format(calendarMonth, "MMMM yyyy")}
              </h2>
              <div className="flex space-x-2">
                <Button variant="outline" size="icon" onClick={handlePrevMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {renderCalendarDays()}
            </div>
            
            <div className="mt-6 flex items-center justify-center space-x-6 flex-wrap">
              <div className="flex items-center m-2">
                <div className="h-4 w-4 rounded-full bg-luna-pink mr-2"></div>
                <span className="text-sm">Period Days</span>
              </div>
              <div className="flex items-center m-2">
                <div className="h-4 w-4 rounded-full bg-luna-purple mr-2"></div>
                <span className="text-sm">Selected Day</span>
              </div>
              <div className="flex items-center m-2">
                <div className="h-4 w-4 rounded-full border-2 border-luna-purple mr-2"></div>
                <span className="text-sm">Today</span>
              </div>
            </div>
          </Card>
          
          {/* Stats Section */}
          <Card className="p-6 shadow-md bg-white">
            <h2 className="text-xl font-bold mb-4 text-gray-800">Cycle Stats</h2>
            
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Current Cycle</p>
                <p className="text-lg font-medium">{calculateCurrentDay()}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Next Period</p>
                <p className="text-lg font-medium">{calculateNextPeriod()}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Average Cycle Length</p>
                <p className="text-lg font-medium">{cycleLength} days</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Average Period Length</p>
                <p className="text-lg font-medium">{periodLength} days</p>
              </div>
            </div>
            
            <div className="mt-6">
              <div className="h-2 bg-gray-200 rounded-full w-full">
                <div 
                  className="h-2 bg-luna-purple rounded-full" 
                  style={{ 
                    width: `${periodStart ? (differenceInDays(new Date(), periodStart) % cycleLength) / cycleLength * 100 : 28}%` 
                  }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Period</span>
                <span>Ovulation</span>
                <span>Next Period</span>
              </div>
            </div>
            
            <Collapsible 
              open={isFormOpen} 
              onOpenChange={setIsFormOpen}
              className="mt-6"
            >
              <CollapsibleTrigger asChild>
                <Button variant="outline" className="w-full mt-4">
                  {isFormOpen ? "Hide Period Form" : "Enter Period History"}
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-4">
                <PeriodHistoryForm onSave={handleSavePeriodHistory} />
              </CollapsibleContent>
            </Collapsible>
          </Card>
        </div>
        
        {/* Daily Log Section */}
        <Card className="mt-8 p-6 shadow-md bg-white">
          <h2 className="text-xl font-bold mb-4 text-gray-800">Daily Log: {format(selectedDate, "MMMM d, yyyy")}</h2>
          
          <Tabs defaultValue="symptoms" className="w-full">
            <TabsList className="mb-6 bg-purple-50 p-1 border border-gray-200 rounded-lg">
              <TabsTrigger value="symptoms">Symptoms</TabsTrigger>
              <TabsTrigger value="flow">Flow</TabsTrigger>
              <TabsTrigger value="mood">Mood</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="symptoms">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {symptoms.map(symptom => (
                  <Button
                    key={symptom.id}
                    variant={selectedSymptoms.includes(symptom.id) ? "default" : "outline"}
                    className={`justify-start ${selectedSymptoms.includes(symptom.id) ? "bg-luna-purple" : ""}`}
                    onClick={() => handleSymptomToggle(symptom.id)}
                  >
                    <div className={`h-3 w-3 rounded-full ${symptom.color} mr-2`}></div>
                    {symptom.name}
                  </Button>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="flow">
              <div className="space-y-6">
                <p className="text-gray-600 mb-2">Select your flow level for today:</p>
                
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFlowLevel(Math.max(0, flowLevel - 1))}
                    disabled={flowLevel === 0}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  
                  <div className="flex-1 mx-4">
                    <div className="h-4 bg-gray-200 rounded-full">
                      <div 
                        className="h-4 bg-gradient-to-r from-pink-200 to-red-500 rounded-full transition-all duration-300" 
                        style={{ width: `${(flowLevel / 5) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between mt-2 text-xs text-gray-500">
                      <span>Light</span>
                      <span>Medium</span>
                      <span>Heavy</span>
                    </div>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setFlowLevel(Math.min(5, flowLevel + 1))}
                    disabled={flowLevel === 5}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="text-center">
                  <Badge variant="outline" className="text-lg py-1 px-4">
                    {flowLevel === 0 && "None"}
                    {flowLevel === 1 && "Very Light"}
                    {flowLevel === 2 && "Light"}
                    {flowLevel === 3 && "Medium"}
                    {flowLevel === 4 && "Heavy"}
                    {flowLevel === 5 && "Very Heavy"}
                  </Badge>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="mood">
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
                {moodOptions.map(mood => (
                  <Button
                    key={mood.id}
                    variant={selectedMood === mood.id ? "default" : "outline"}
                    className={`flex-col h-24 ${selectedMood === mood.id ? "bg-luna-purple" : ""}`}
                    onClick={() => handleMoodSelection(mood.id)}
                  >
                    <span className="text-2xl mb-2">{mood.emoji}</span>
                    <span>{mood.name}</span>
                  </Button>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="notes">
              <textarea 
                className="w-full h-40 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-luna-purple" 
                placeholder="Add notes about your day here..."
              ></textarea>
            </TabsContent>
          </Tabs>
          
          <div className="mt-8 flex justify-end">
            <Button className="bg-luna-purple hover:bg-purple-600">
              Save Entry
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Tracker;
