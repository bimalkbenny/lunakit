
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Calendar, Package, Heart, ChevronRight, ArrowRight } from "lucide-react";
import Navigation from "@/components/Navigation";
import SocialLinks from "@/components/SocialLinks";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      {/* Hero Section */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-luna-light-purple to-luna-blue">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="w-full md:w-1/2 animate-fade-in">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-luna-purple leading-tight mb-6">
                Track & Care For Your <span className="text-purple-600">Monthly Cycle</span>
              </h1>
              <p className="text-lg text-gray-700 mb-8 max-w-lg">
                Track your period, shop for period essentials, and discover comfort during your cycle with Luna Kit.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-luna-purple hover:bg-purple-600 text-white px-6 py-6 rounded-lg text-lg transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px]"
                  asChild
                >
                  <Link to="/tracker">Track Now <ArrowRight className="ml-2 h-5 w-5" /></Link>
                </Button>
                <Button
                  variant="outline"
                  className="border-luna-purple text-luna-purple hover:bg-luna-light-purple px-6 py-6 rounded-lg text-lg transition-all duration-300 hover:shadow-lg"
                  asChild
                >
                  <Link to="/shop">Shop Products</Link>
                </Button>
              </div>
              
              <div className="mt-8">
                <SocialLinks />
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center animate-fade-in delay-200">
              <div className="relative">
                <div className="w-64 h-64 md:w-80 md:h-80 bg-white p-4 rounded-full shadow-xl flex items-center justify-center rotate-3 transition-all duration-500 hover:rotate-6">
                  <div className="w-56 h-56 md:w-72 md:h-72 bg-luna-pink rounded-full flex items-center justify-center animate-float">
                    <Heart className="h-20 w-20 text-white animate-pulse" />
                  </div>
                </div>
                <div className="absolute top-0 right-0 w-20 h-20 bg-luna-blue rounded-full -mt-6 -mr-6 shadow-lg animate-float" style={{ animationDelay: '1s' }}></div>
                <div className="absolute bottom-0 left-0 w-16 h-16 bg-luna-purple rounded-full -mb-4 -ml-4 shadow-lg animate-float" style={{ animationDelay: '2s' }}></div>
                <div className="absolute bottom-1/4 right-0 w-12 h-12 bg-pink-300 rounded-full shadow-lg animate-float" style={{ animationDelay: '1.5s' }}></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="section-spacing bg-white">
        <div className="content-container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-luna-purple animate-fade-in">
            Everything You Need In One Place
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Period Tracker Card */}
            <div className="luna-card flex flex-col animate-fade-in delay-100">
              <div className="h-14 w-14 rounded-full bg-luna-light-purple flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110">
                <Calendar className="h-6 w-6 text-luna-purple" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-luna-purple">Period Tracker</h3>
              <p className="text-gray-600 mb-6 flex-grow">
                Track your cycle, symptoms, and get predictions for your next period. Stay prepared and in control.
              </p>
              <Link to="/tracker" className="flex items-center text-luna-purple font-medium hover:underline mt-auto group">
                Track Now <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>

            {/* Shop Card */}
            <div className="luna-card flex flex-col animate-fade-in delay-200">
              <div className="h-14 w-14 rounded-full bg-luna-light-purple flex items-center justify-center mb-4">
                <Package className="h-6 w-6 text-luna-purple" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-luna-purple">Shop Period Products</h3>
              <p className="text-gray-600 mb-6 flex-grow">
                Get comfort kits with pads, intimate wash, chocolates, tissues, toilet covers and pain relief patches.
              </p>
              <Link to="/shop" className="flex items-center text-luna-purple font-medium hover:underline mt-auto group">
                Shop Now <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>

            {/* Company Overview Card */}
            <div className="luna-card flex flex-col animate-fade-in delay-300">
              <div className="h-14 w-14 rounded-full bg-luna-light-purple flex items-center justify-center mb-4">
                <Heart className="h-6 w-6 text-luna-purple" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-luna-purple">Our Company</h3>
              <p className="text-gray-600 mb-6 flex-grow">
                Learn about our mission to make period care comfortable, accessible, and stress-free for everyone.
              </p>
              <Link to="/about" className="flex items-center text-luna-purple font-medium hover:underline mt-auto group">
                Learn More <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Kit Section */}
      <section className="section-spacing bg-luna-light-purple">
        <div className="content-container">
          <div className="flex flex-col md:flex-row items-center md:space-x-12">
            <div className="w-full md:w-1/2 mb-12 md:mb-0 animate-fade-in">
              <div className="bg-white p-6 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl hover:translate-y-[-5px]">
                <div className="aspect-square rounded-xl bg-gradient-to-br from-luna-pink to-pink-300 flex items-center justify-center p-8">
                  <div className="grid grid-cols-2 gap-6 w-full">
                    <div className="bg-white rounded-lg p-4 shadow-md flex flex-col items-center justify-center animate-fade-in delay-100 hover-scale">
                      <div className="w-12 h-12 bg-luna-light-purple rounded-lg flex items-center justify-center mb-2">
                        <Package className="h-6 w-6 text-luna-purple" />
                      </div>
                      <span className="text-sm text-center font-medium">Sanitary Pads</span>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-md flex flex-col items-center justify-center animate-fade-in delay-200 hover-scale">
                      <div className="w-12 h-12 bg-luna-light-purple rounded-lg flex items-center justify-center mb-2">
                        <Package className="h-6 w-6 text-luna-purple" />
                      </div>
                      <span className="text-sm text-center font-medium">Intimate Wash</span>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-md flex flex-col items-center justify-center animate-fade-in delay-300 hover-scale">
                      <div className="w-12 h-12 bg-luna-light-purple rounded-lg flex items-center justify-center mb-2">
                        <Package className="h-6 w-6 text-luna-purple" />
                      </div>
                      <span className="text-sm text-center font-medium">Chocolates</span>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-md flex flex-col items-center justify-center animate-fade-in delay-400 hover-scale">
                      <div className="w-12 h-12 bg-luna-light-purple rounded-lg flex items-center justify-center mb-2">
                        <Package className="h-6 w-6 text-luna-purple" />
                      </div>
                      <span className="text-sm text-center font-medium">Pain Relief</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-full md:w-1/2 animate-fade-in delay-200">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-luna-purple">
                The Perfect Period Comfort Kit
              </h2>
              <p className="text-gray-700 mb-6">
                Our specially designed comfort kits include everything you need to make your period more comfortable:
              </p>
              <ul className="space-y-5 mb-8">
                <li className="flex items-center transform transition-transform hover:translate-x-2">
                  <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-4 shadow-md">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-800">High-quality sanitary pads for ultimate comfort</span>
                </li>
                <li className="flex items-center transform transition-transform hover:translate-x-2">
                  <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-4 shadow-md">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-800">Gentle intimate wash for freshness and hygiene</span>
                </li>
                <li className="flex items-center transform transition-transform hover:translate-x-2">
                  <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-4 shadow-md">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-800">Delicious chocolates to satisfy cravings</span>
                </li>
                <li className="flex items-center transform transition-transform hover:translate-x-2">
                  <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-4 shadow-md">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-800">Pain relief heating patches for cramp relief</span>
                </li>
                <li className="flex items-center transform transition-transform hover:translate-x-2">
                  <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-4 shadow-md">
                    <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-800">Tissues and disposable toilet covers for on-the-go</span>
                </li>
              </ul>
              <Button 
                className="bg-luna-purple hover:bg-purple-600 text-white transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px]" 
                asChild
              >
                <Link to="/shop">Shop Kits Now</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Sign Up Call to Action */}
      <section className="section-spacing bg-gradient-to-r from-purple-100 to-luna-light-purple">
        <div className="content-container">
          <div className="text-center max-w-3xl mx-auto animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-luna-purple">
              Join the Luna Kit Community
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              Create an account to track your cycle, save your favorite products, and get personalized period care recommendations.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                className="bg-luna-purple hover:bg-purple-600 text-white px-8 py-6 rounded-lg text-lg transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px]"
                asChild
              >
                <Link to="/signup">Sign Up Now</Link>
              </Button>
              <Button 
                variant="outline" 
                className="border-luna-purple text-luna-purple hover:bg-luna-light-purple px-8 py-6 rounded-lg text-lg transition-all duration-300"
                asChild
              >
                <Link to="/login">Sign In</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="h-10 w-10 rounded-full bg-luna-purple flex items-center justify-center mr-3">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold text-luna-purple">Luna Kit</span>
            </div>
            <SocialLinks />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold text-lg mb-4 text-luna-purple">Products</h3>
              <ul className="space-y-2">
                <li><Link to="/shop" className="text-gray-600 hover:text-luna-purple">Period Kits</Link></li>
                <li><Link to="/shop" className="text-gray-600 hover:text-luna-purple">Sanitary Pads</Link></li>
                <li><Link to="/shop" className="text-gray-600 hover:text-luna-purple">Hygiene Products</Link></li>
                <li><Link to="/shop" className="text-gray-600 hover:text-luna-purple">Pain Relief</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4 text-luna-purple">Features</h3>
              <ul className="space-y-2">
                <li><Link to="/tracker" className="text-gray-600 hover:text-luna-purple">Period Tracker</Link></li>
                <li><Link to="/shop" className="text-gray-600 hover:text-luna-purple">Custom Kits</Link></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Subscriptions</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Reviews</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4 text-luna-purple">Company</h3>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-gray-600 hover:text-luna-purple">About Us</Link></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Careers</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Press</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4 text-luna-purple">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Blog</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">FAQ</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-600 hover:text-luna-purple">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6 text-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} Luna Kit. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
