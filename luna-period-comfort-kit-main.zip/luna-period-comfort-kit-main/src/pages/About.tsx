
import { Heart, Calendar, Package } from "lucide-react";
import { Card } from "@/components/ui/card";
import Navigation from "@/components/Navigation";

const About = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-luna-light-purple to-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-luna-purple mb-6">
            Our Mission
          </h1>
          <p className="text-lg md:text-xl max-w-3xl mx-auto text-gray-700">
            At Luna Kit, we're dedicated to making period care comfortable, accessible, 
            and stress-free for everyone. We believe in creating products that truly 
            understand and address the needs of those experiencing periods.
          </p>
        </div>
      </div>
      
      {/* Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="w-full md:w-1/2">
              <h2 className="text-3xl font-bold text-luna-purple mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Luna Kit was founded in 2023 by a team of individuals who were tired of 
                the discomfort and inconvenience that often comes with periods. We recognized 
                that most period products focused on only one aspect of period care, while 
                neglecting the overall experience.
              </p>
              <p className="text-gray-700 mb-4">
                Our founder, after experiencing a particularly difficult period while traveling, 
                wished for a single kit that contained everything needed for comfort and hygiene. 
                When she couldn't find one, she decided to create it herself.
              </p>
              <p className="text-gray-700">
                Thus, Luna Kit was born - a comprehensive period care solution that combines 
                tracking technology with carefully curated comfort kits containing all the 
                essentials needed during menstruation.
              </p>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative">
                <div className="w-64 h-64 bg-luna-light-purple rounded-full flex items-center justify-center">
                  <Heart className="h-20 w-20 text-luna-purple animate-pulse" />
                </div>
                <div className="absolute top-12 right-0 w-32 h-32 bg-luna-pink rounded-full -mr-16 flex items-center justify-center">
                  <Package className="h-10 w-10 text-white" />
                </div>
                <div className="absolute bottom-12 left-0 w-32 h-32 bg-luna-blue rounded-full -ml-16 flex items-center justify-center">
                  <Calendar className="h-10 w-10 text-luna-purple" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Values Section */}
      <section className="py-16 bg-luna-light-purple/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-luna-purple mb-12 text-center">Our Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-8 text-center border-t-4 border-luna-purple">
              <div className="w-20 h-20 bg-white rounded-full mx-auto mb-6 flex items-center justify-center shadow-md">
                <Heart className="h-10 w-10 text-luna-purple" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-luna-purple">Comfort First</h3>
              <p className="text-gray-700">
                We prioritize your comfort above all else. Our products are designed to make 
                your period days more comfortable and manageable.
              </p>
            </Card>
            
            <Card className="p-8 text-center border-t-4 border-luna-pink">
              <div className="w-20 h-20 bg-white rounded-full mx-auto mb-6 flex items-center justify-center shadow-md">
                <Package className="h-10 w-10 text-luna-pink" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-luna-purple">Quality Products</h3>
              <p className="text-gray-700">
                We carefully select each item in our kits to ensure they meet the highest 
                standards of quality and effectiveness.
              </p>
            </Card>
            
            <Card className="p-8 text-center border-t-4 border-luna-blue">
              <div className="w-20 h-20 bg-white rounded-full mx-auto mb-6 flex items-center justify-center shadow-md">
                <Calendar className="h-10 w-10 text-luna-blue" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-luna-purple">Empowerment</h3>
              <p className="text-gray-700">
                We believe in empowering individuals through knowledge and tools that help 
                them understand and manage their menstrual cycles.
              </p>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-luna-purple mb-12 text-center">
            Our Team
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((person) => (
              <div key={person} className="text-center">
                <div className="w-32 h-32 bg-luna-light-purple rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-medium text-luna-purple mb-1">Team Member</h3>
                <p className="text-sm text-gray-600 mb-3">Position</p>
                <p className="text-sm text-gray-600">
                  Passionate about making periods more comfortable and manageable for everyone.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section className="py-16 bg-luna-purple">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-8">Get in Touch</h2>
          <p className="text-lg text-white/90 max-w-2xl mx-auto mb-8">
            Have questions about our products or want to collaborate? We'd love to hear from you!
          </p>
          <div className="inline-block">
            <a href="#" className="bg-white text-luna-purple px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors">
              Contact Us
            </a>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-8 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="h-8 w-8 rounded-full bg-luna-purple flex items-center justify-center mr-2">
                <Heart className="h-4 w-4 text-white" />
              </div>
              <span className="text-lg font-bold text-luna-purple">Luna Kit</span>
            </div>
            <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-gray-600">
              <a href="/tracker" className="hover:text-luna-purple">Period Tracker</a>
              <a href="/shop" className="hover:text-luna-purple">Shop</a>
              <a href="/about" className="hover:text-luna-purple">About Us</a>
              <a href="#" className="hover:text-luna-purple">Privacy Policy</a>
              <a href="#" className="hover:text-luna-purple">Terms of Service</a>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Luna Kit. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;
