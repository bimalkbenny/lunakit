
import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, CreditCard, ChevronRight, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";

const Checkout = () => {
  const [cartItems, setCartItems] = useState([
    { id: 1, name: "Basic Comfort Kit", price: 12.99, quantity: 1 },
    { id: 2, name: "Premium Comfort Kit", price: 18.99, quantity: 2 }
  ]);
  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  
  const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const shipping = 4.99;
  const total = subtotal + shipping;
  
  const handleCheckout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setStep(2);
      setIsProcessing(false);
      toast({
        title: "Order placed successfully!",
        description: "Thank you for your purchase. You will receive a confirmation email shortly.",
      });
    }, 2000);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-luna-light-purple/30">
      <Navigation />
      
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-center mb-10 text-luna-purple animate-fade-in">
          {step === 1 ? "Checkout" : "Order Confirmation"}
        </h1>
        
        {step === 1 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card className="mb-8 animate-fade-in">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Your Cart
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex justify-between items-center pb-4 border-b hover-scale transition-all-300">
                        <div>
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                        </div>
                        <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="animate-fade-in delay-100">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="mr-2 h-5 w-5" />
                    Payment Information
                  </CardTitle>
                  <CardDescription>Enter your shipping and payment details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="font-medium">Shipping Address</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2 sm:col-span-1">
                          <Label htmlFor="firstName">First Name</Label>
                          <Input id="firstName" className="mt-1" />
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input id="lastName" className="mt-1" />
                        </div>
                        <div className="col-span-2">
                          <Label htmlFor="address">Address</Label>
                          <Input id="address" className="mt-1" />
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                          <Label htmlFor="city">City</Label>
                          <Input id="city" className="mt-1" />
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                          <Label htmlFor="zipCode">ZIP Code</Label>
                          <Input id="zipCode" className="mt-1" />
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="font-medium">Payment Method</h3>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input id="cardNumber" placeholder="1234 5678 9012 3456" className="mt-1" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiration">Expiration Date</Label>
                            <Input id="expiration" placeholder="MM/YY" className="mt-1" />
                          </div>
                          <div>
                            <Label htmlFor="cvc">CVC</Label>
                            <Input id="cvc" placeholder="123" className="mt-1" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="animate-fade-in delay-200">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping</span>
                      <span>${shipping.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                    <Button 
                      onClick={handleCheckout} 
                      className="w-full bg-luna-purple hover:bg-purple-600 transition-all-300"
                      disabled={isProcessing}
                    >
                      {isProcessing ? (
                        <div className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Processing...
                        </div>
                      ) : (
                        <div className="flex items-center">
                          Place Order <ChevronRight className="ml-2 h-4 w-4" />
                        </div>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          <div className="max-w-lg mx-auto">
            <Card className="animate-scale-in">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-4 py-6">
                  <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-center">Order Placed Successfully!</h2>
                  <p className="text-center text-gray-500">
                    Thank you for your purchase. Your order confirmation has been sent to your email.
                  </p>
                  <div className="bg-gray-50 w-full p-4 rounded-lg my-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-500">Order Number:</span>
                      <span className="font-medium">#LK-{Math.floor(100000 + Math.random() * 900000)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Order Total:</span>
                      <span className="font-medium">${total.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="flex space-x-4">
                    <Button asChild>
                      <Link to="/">Back to Home</Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link to="/shop">Continue Shopping</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default Checkout;
